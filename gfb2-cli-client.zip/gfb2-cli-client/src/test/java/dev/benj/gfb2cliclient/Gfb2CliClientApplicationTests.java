package dev.benj.gfb2cliclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gfb2CliClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
