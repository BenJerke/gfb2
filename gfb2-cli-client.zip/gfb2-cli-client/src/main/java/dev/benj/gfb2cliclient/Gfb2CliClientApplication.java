package dev.benj.gfb2cliclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gfb2CliClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Gfb2CliClientApplication.class, args);
	}

}
